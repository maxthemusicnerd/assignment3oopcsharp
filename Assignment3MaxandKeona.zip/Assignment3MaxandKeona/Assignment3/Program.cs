﻿using Assignment3.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    internal class Program
    {
        public static void Main(string[] args) 
        {
            //some test code, I hope that I remember to remove it
            SLL users = new SLL();
			users.AddLast(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
			users.AddLast(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));

            users.RemoveLast();

			users.AddLast(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"));
			users.AddLast(new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999"));

            users.Replace(new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999"), 0);

            Console.WriteLine(users.Count());   
            User[] array = users.intoArray();
            foreach (var item in array)
            {
                Console.WriteLine(item.Name);
            }
        }
    }
}
