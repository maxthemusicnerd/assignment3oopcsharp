﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Utility
{
	[DataContract]
	[KnownType(typeof(User))]
	public class UserNode
	{
		[DataMember]
		private User User { get; set; }
		[DataMember]
		private UserNode nextNode;
		public UserNode(User user, UserNode NextNode) 
		{
			User = user;
			nextNode = NextNode;
		}

		public void setNextNode(UserNode NextNode) 
		{
			nextNode = NextNode;
		}

		public UserNode getNextNode()
		{
			return nextNode;
		}

		public User getUser() { return User; }
		public void setValue(User Value)
		{
			User = Value;
		}
	}
}
