﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Utility
{
	using System;

	public class CannotRemoveException : Exception
	{
		// Default constructor
		public CannotRemoveException() : base("Cannot remove item from the list.")
		{
		}
		public CannotRemoveException(string message) : base(message)
		{
		}

	}

	public class CannotConvertIntoArray : Exception
	{
		public CannotConvertIntoArray() : base("Cannot convert empty linked list into array")
		{
		}
	}
}
