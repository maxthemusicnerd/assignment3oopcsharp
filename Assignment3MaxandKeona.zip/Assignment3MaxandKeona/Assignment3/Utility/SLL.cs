﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Utility
{
	[DataContract] 
	[KnownType(typeof(User))]
	public class SLL : ILinkedListADT
	{
		[DataMember]
		private UserNode head;
		[DataMember]
		private int length;

		
		public SLL() 
		{
			head = null;
			length = 0;
		}
		/// <summary>
        /// Checks if the list is empty.
        /// </summary>
        /// <returns>True if it is empty.</returns>
        public bool IsEmpty()
		{
			if (head == null)
			{
				return true;
			} else
			{
				return false;
			}

		}

		/// <summary>
		/// Clears the list.
		/// </summary>
		public void Clear()
		{
			head = null;
			length = 0;
		}

		/// <summary>
		/// Adds to the end of the list.
		/// </summary>
		/// <param name="value">Value to append.</param>
		public void AddLast(User value)
		{
			UserNode currentNode = head;
			UserNode newUserNode = new UserNode(value, null);
			length++;
			if (head == null)
			{
				head = newUserNode;
				return;
			}
			while (currentNode.getNextNode() != null)
			{
				currentNode = currentNode.getNextNode();
			}
			currentNode.setNextNode(newUserNode);
		}

		/// <summary>
		/// Prepends (adds to beginning) value to the list.
		/// </summary>
		/// <param name="value">Value to store inside element.</param>
		public void AddFirst(User value)
		{
			UserNode newUserNode = new UserNode(value, head);
			head = newUserNode;
			length++;
		}

		/// <summary>
		/// Adds a new element at a specific position.
		/// </summary>
		/// <param name="value">Value that element is to contain.</param>
		/// <param name="index">Index to add new element at.</param>
		/// <exception cref="IndexOutOfRangeException">Thrown if index is negative or past the size of the list.</exception>
		public void Add(User value, int index)
		{
			if (index < 0 || index > length)
			{
				throw new IndexOutOfRangeException();
			}
			if (index == length)
			{
				AddLast(value);
				return;
			}
			if (index == 0)
			{
				AddFirst(value);
				return;
			} 
			UserNode newUserNode = new UserNode(value, null);
			UserNode currentNode = head;
			int counter = 0;
			UserNode previousNode = null;
			while (counter != index)
			{
				previousNode = currentNode;
				currentNode = currentNode.getNextNode();
				counter++;
			}
			newUserNode.setNextNode(currentNode);
			previousNode.setNextNode(newUserNode);
			length++;	
		}

		/// <summary>
		/// Replaces the value  at index.
		/// </summary>
		/// <param name="value">Value to replace.</param>
		/// <param name="index">Index of element to replace.</param>
		/// <exception cref="IndexOutOfRangeException">Thrown if index is negative or larger than size - 1 of list.</exception>
		public void Replace(User value, int index)
		{
			if (index < 0 || index > length - 1)
			{
				throw new IndexOutOfRangeException();
			}
			if (index == 0)
			{
				head = new UserNode(value, head.getNextNode());
				return;
			}
			UserNode currentNode = head;
			int counter = 0;
			UserNode previousNode = null;
			while (counter != index)
			{
				previousNode = currentNode;
				currentNode = currentNode.getNextNode();
				counter++;
			}
			currentNode.setValue(value);
		}

		/// <summary>
		/// Gets the number of elements in the list.
		/// </summary>
		/// <returns>Size of list (0 meaning empty)</returns>
		public int Count()
		{
			return length;
		}

		/// <summary>
		/// Removes first element from list
		/// </summary>
		/// <exception cref="CannotRemoveException">Thrown if list is empty.</exception>
		public void RemoveFirst()
		{
			if (head == null)
			{
				throw new CannotRemoveException();
			}
			head = head.getNextNode();
			length--;
		}

		/// <summary>
		/// Removes last element from list
		/// </summary>
		/// <exception cref="CannotRemoveException">Thrown if list is empty.</exception>
		public void RemoveLast()
		{
			if (head == null)
			{
				throw new CannotRemoveException();
			}
			if (head.getNextNode() == null)
			{
				head = null;
				length--;
				return;
			}
			UserNode currentNode = head;
			while(currentNode.getNextNode().getNextNode() != null)
			{
				currentNode = currentNode.getNextNode();
			}
			currentNode.setNextNode(null);
			length--;
		}

		/// <summary>
		/// Removes element at index from list, reducing the size.
		/// </summary>
		/// <param name="index">Index of element to remove.</param>
		/// <exception cref="IndexOutOfRangeException">Thrown if index is negative or larger than size - 1 of list.</exception>
		public void Remove(int index)
		{
			if (index < 0 || index > length - 1)
			{
				throw new IndexOutOfRangeException();
			}
			if (index == length - 1)
			{
				RemoveLast();
				return;
			}
			if (index == 0)
			{
				RemoveFirst();
				return;
			}
			UserNode currentNode = head;
			int counter = 0;
			UserNode previousNode = null;
			while (counter != index)
			{
				previousNode = currentNode;
				currentNode = currentNode.getNextNode();
				counter++;
			}
			previousNode.setNextNode(currentNode.getNextNode());
			length--;
		}

		/// <summary>
		/// Gets the value at the specified index.
		/// </summary>
		/// <param name="index">Index of element to get.</param>
		/// <returns>Value of node at index</returns>
		/// <exception cref="IndexOutOfRangeException">Thrown if index is negative or larger than size - 1 of list.</exception>
		public User GetValue(int index)
		{
			if (index < 0 || index >= length)
			{
				throw new IndexOutOfRangeException();
			}
			UserNode currentNode = head;
			int counter = 0;
			while (counter != index)
			{
				currentNode = currentNode.getNextNode();
				counter++;
			}
			return currentNode.getUser();
		}

		/// <summary>
		/// Gets the first index of element containing value.
		/// </summary>
		/// <param name="value">Value to find index of.</param>
		/// <returns>First of index of node with matching value or -1 if not found.</returns>
		public int IndexOf(User value)
		{
			int index = 0;
			UserNode currentNode = head;
			while (currentNode != null)
			{
				if (currentNode.getUser().Equals(value))
				{
					return index;
				}
				index++;
				currentNode = currentNode.getNextNode();
			}
			return -1;
		}

		/// <summary>
		/// Go through nodes and check if one has value.
		/// </summary>
		/// <param name="value">Value to find index of.</param>
		/// <returns>True if element exists with value.</returns>
		public bool Contains(User value)
		{
			UserNode currentNode = head;
			while (currentNode != null)
			{
				if (currentNode.getUser().Equals(value))
				{
					return true;
				}
				currentNode = currentNode.getNextNode();
			}
			return false;
		}

		public User[] intoArray()
		{
			if (head == null)
			{
				//while you could just have it return an array of length [0]
				//that means that it'll be essentially immutable because how do you edit an array
				//with no indices. I think each array should have at least one item in it
				throw new CannotConvertIntoArray();
			}
			User[] array = new User[length];
			int counter = 0;
			UserNode currentNode = head;
			while (currentNode != null)
			{
				array[counter] = currentNode.getUser();
				counter++;
				currentNode = currentNode.getNextNode();
			}
			return array;
		}
	}
}
